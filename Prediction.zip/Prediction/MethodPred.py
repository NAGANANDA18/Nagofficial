'''
# Step 1: Import Libraries
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import GridSearchCV

# Step 2: Load the Dataset
file_path = 'InstagramPosts.csv'  # Update this path
data = pd.read_csv(file_path)

# Step 3: Preprocess the Data

# Fill missing values for 'hashtags' with an empty string
data['hashtags'] = data['hashtags'].fillna('')

# Convert 'date_posted' to a datetime object and extract the hour
# Step 3: Preprocess the Data

# Step 3: Preprocess the Data

# Step 3: Preprocess the Data

# Remove extra quotation marks from the date strings
data['date_posted'] = data['date_posted'].str.replace('"', '')

# Convert 'date_posted' to a datetime object, specifying the format
data['Hour_Posted'] = pd.to_datetime(data['date_posted'], format='%Y-%m-%dT%H:%M:%S.%fZ').dt.hour


# Continue with other preprocessing steps if needed
# Feature Engineering: Length of the post description
data['Post_Length'] = data['description'].apply(len)

# Count the number of hashtags in each post
data['Hashtag_Count'] = data['hashtags'].apply(lambda x: len(x.split(',')))

# Select relevant features
features = ['Hour_Posted', 'Post_Length', 'Hashtag_Count', 'followers', 'num_comments', 'video_play_count']
X = data[features]

# Target variable: Number of likes
y = data['likes']

# Step 4: Split the Data into Training and Testing Sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Step 5: Train a Machine Learning Model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Step 6: Evaluate the Model
y_pred = model.predict(X_test)

# Evaluate the model
mae = mean_absolute_error(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)

print(f'Mean Absolute Error (MAE): {mae}')
print(f'Mean Squared Error (MSE): {mse}')
print(f'Root Mean Squared Error (RMSE): {rmse}')

# Step 7: Visualize the Results
plt.figure(figsize=(10, 6))
sns.scatterplot(x=y_test, y=y_pred)
plt.xlabel('Actual Number of Likes')
plt.ylabel('Predicted Number of Likes')
plt.title('Actual vs Predicted Number of Likes')
plt.show()

# Step 8: Optimize and Fine-tune the Model (Optional)
# Define parameter grid for hyperparameter tuning
param_grid = {
    'n_estimators': [100, 200, 300],
    'max_depth': [10, 20, None],
    'min_samples_split': [2, 5, 10]
}

# Initialize GridSearchCV
grid_search = GridSearchCV(estimator=model, param_grid=param_grid, cv=5, n_jobs=-1, verbose=2)

# Fit the grid search to the data
grid_search.fit(X_train, y_train)

# Get the best parameters
best_params = grid_search.best_params_
print(f'Best Parameters: {best_params}')

# Train the model with the best parameters
best_model = grid_search.best_estimator_

# Make predictions with the best model
y_pred_best = best_model.predict(X_test)

# Evaluate the best model
mae_best = mean_absolute_error(y_test, y_pred_best)
rmse_best = np.sqrt(mean_squared_error(y_test, y_pred_best))

print(f'Optimized MAE: {mae_best}')
print(f'Optimized RMSE: {rmse_best}')
# Step 1: Import Libraries
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import GridSearchCV

# Step 2: Load the Dataset
file_path = 'InstagramPosts.csv'  # Update this path
data = pd.read_csv(file_path)

# Step 3: Preprocess the Data

# Fill missing values for 'hashtags' with an empty string
data['hashtags'] = data['hashtags'].fillna('')

# Convert 'date_posted' to a datetime object and extract the hour
# Step 3: Preprocess the Data

# Step 3: Preprocess the Data

# Step 3: Preprocess the Data

# Remove extra quotation marks from the date strings
data['date_posted'] = data['date_posted'].str.replace('"', '')

# Convert 'date_posted' to a datetime object, specifying the format
data['Hour_Posted'] = pd.to_datetime(data['date_posted'], format='%Y-%m-%dT%H:%M:%S.%fZ').dt.hour


# Continue with other preprocessing steps if needed
# Feature Engineering: Length of the post description
data['Post_Length'] = data['description'].apply(len)

# Count the number of hashtags in each post
data['Hashtag_Count'] = data['hashtags'].apply(lambda x: len(x.split(',')))

# Select relevant features
features = ['Hour_Posted', 'Post_Length', 'Hashtag_Count', 'followers', 'num_comments', 'video_play_count']
X = data[features]

# Target variable: Number of likes
y = data['likes']

# Step 4: Split the Data into Training and Testing Sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Step 5: Train a Machine Learning Model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Step 6: Evaluate the Model
y_pred = model.predict(X_test)

# Evaluate the model
mae = mean_absolute_error(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)

print(f'Mean Absolute Error (MAE): {mae}')
print(f'Mean Squared Error (MSE): {mse}')
print(f'Root Mean Squared Error (RMSE): {rmse}')

# Step 7: Visualize the Results
plt.figure(figsize=(10, 6))
sns.scatterplot(x=y_test, y=y_pred)
plt.xlabel('Actual Number of Likes')
plt.ylabel('Predicted Number of Likes')
plt.title('Actual vs Predicted Number of Likes')
plt.show()

# Step 8: Optimize and Fine-tune the Model (Optional)
# Define parameter grid for hyperparameter tuning
param_grid = {
    'n_estimators': [100, 200, 300],
    'max_depth': [10, 20, None],
    'min_samples_split': [2, 5, 10]
}

# Initialize GridSearchCV
grid_search = GridSearchCV(estimator=model, param_grid=param_grid, cv=5, n_jobs=-1, verbose=2)

# Fit the grid search to the data
grid_search.fit(X_train, y_train)

# Get the best parameters
best_params = grid_search.best_params_
print(f'Best Parameters: {best_params}')

# Train the model with the best parameters
best_model = grid_search.best_estimator_

# Make predictions with the best model
y_pred_best = best_model.predict(X_test)

# Evaluate the best model
mae_best = mean_absolute_error(y_test, y_pred_best)
rmse_best = np.sqrt(mean_squared_error(y_test, y_pred_best))

print(f'Optimized MAE: {mae_best}')
print(f'Optimized RMSE: {rmse_best}')
'''

#=========================================================================================================================================





'''
# Step 1: Import Libraries
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import GridSearchCV
import tkinter as tk
from tkinter import messagebox
from tkinter import ttk

# Step 2: Load the Dataset
file_path = 'InstagramPosts.csv'  # Update this path if necessary
data = pd.read_csv(file_path)

# Step 3: Preprocess the Data
# Fill missing values for 'hashtags' with an empty string
data['hashtags'] = data['hashtags'].fillna('')

# Remove extra quotation marks from the date strings
data['date_posted'] = data['date_posted'].str.replace('"', '')

# Convert 'date_posted' to a datetime object and extract the hour
data['Hour_Posted'] = pd.to_datetime(data['date_posted'], format='%Y-%m-%dT%H:%M:%S.%fZ').dt.hour

# Feature Engineering: Length of the post description
data['Post_Length'] = data['description'].apply(len)

# Count the number of hashtags in each post
data['Hashtag_Count'] = data['hashtags'].apply(lambda x: len(x.split(',')))

# Select relevant features
features = ['Hour_Posted', 'Post_Length', 'Hashtag_Count', 'followers', 'num_comments', 'video_play_count']
X = data[features]

# Target variable: Number of likes
y = data['likes']

# Step 4: Split the Data into Training and Testing Sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Step 5: Train a Machine Learning Model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Step 6: Evaluate the Model
y_pred = model.predict(X_test)

# Evaluate the model
mae = mean_absolute_error(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)

print(f'Mean Absolute Error (MAE): {mae}')
print(f'Mean Squared Error (MSE): {mse}')
print(f'Root Mean Squared Error (RMSE): {rmse}')

# Step 7: Visualize the Results
plt.figure(figsize=(10, 6))
sns.scatterplot(x=y_test, y=y_pred)
plt.xlabel('Actual Number of Likes')
plt.ylabel('Predicted Number of Likes')
plt.title('Actual vs Predicted Number of Likes')
plt.show()

# Step 8: Optimize and Fine-tune the Model (Optional)
# Define parameter grid for hyperparameter tuning
param_grid = {
    'n_estimators': [100, 200, 300],
    'max_depth': [10, 20, None],
    'min_samples_split': [2, 5, 10]
}

# Initialize GridSearchCV
grid_search = GridSearchCV(estimator=model, param_grid=param_grid, cv=5, n_jobs=-1, verbose=2)

# Fit the grid search to the data
grid_search.fit(X_train, y_train)

# Get the best parameters
best_params = grid_search.best_params_
print(f'Best Parameters: {best_params}')

# Train the model with the best parameters
best_model = grid_search.best_estimator_

# Make predictions with the best model
y_pred_best = best_model.predict(X_test)

# Evaluate the best model
mae_best = mean_absolute_error(y_test, y_pred_best)
rmse_best = np.sqrt(mean_squared_error(y_test, y_pred_best))

print(f'Optimized MAE: {mae_best}')
print(f'Optimized RMSE: {rmse_best}')

# Step 9: Create a GUI Application for Prediction
# Define the function to make predictions
def predict_likes_and_followers(hour_posted, post_length, hashtag_count, followers, num_comments, video_play_count):
    X_new = pd.DataFrame({
        'Hour_Posted': [hour_posted],
        'Post_Length': [post_length],
        'Hashtag_Count': [hashtag_count],
        'followers': [followers],
        'num_comments': [num_comments],
        'video_play_count': [video_play_count]
    })
    likes_prediction = best_model.predict(X_new)[0]
    return likes_prediction

# Define the function to show graphical presentation
def show_graphical_presentation():
    plt.figure(figsize=(10, 6))
    sns.scatterplot(x=y_test, y=best_model.predict(X_test))
    plt.xlabel('Actual Number of Likes')
    plt.ylabel('Predicted Number of Likes')
    plt.title('Actual vs Predicted Number of Likes')
    plt.show()

# Define the GUI application
class PredictionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Instagram Post Prediction")

        # Create and place widgets
        self.create_widgets()

    def create_widgets(self):
        # Labels and entry fields for input
        ttk.Label(self.root, text="Hour Posted:").grid(row=0, column=0, padx=10, pady=10)
        self.hour_posted_var = tk.DoubleVar()
        ttk.Entry(self.root, textvariable=self.hour_posted_var).grid(row=0, column=1)

        ttk.Label(self.root, text="Post Length:").grid(row=1, column=0, padx=10, pady=10)
        self.post_length_var = tk.DoubleVar()
        ttk.Entry(self.root, textvariable=self.post_length_var).grid(row=1, column=1)

        ttk.Label(self.root, text="Hashtag Count:").grid(row=2, column=0, padx=10, pady=10)
        self.hashtag_count_var = tk.DoubleVar()
        ttk.Entry(self.root, textvariable=self.hashtag_count_var).grid(row=2, column=1)

        ttk.Label(self.root, text="Followers:").grid(row=3, column=0, padx=10, pady=10)
        self.followers_var = tk.DoubleVar()
        ttk.Entry(self.root, textvariable=self.followers_var).grid(row=3, column=1)

        ttk.Label(self.root, text="Number of Comments:").grid(row=4, column=0, padx=10, pady=10)
        self.num_comments_var = tk.DoubleVar()
        ttk.Entry(self.root, textvariable=self.num_comments_var).grid(row=4, column=1)

        ttk.Label(self.root, text="Video Play Count:").grid(row=5, column=0, padx=10, pady=10)
        self.video_play_count_var = tk.DoubleVar()
        ttk.Entry(self.root, textvariable=self.video_play_count_var).grid(row=5, column=1)

        # Buttons for prediction and visualization
        ttk.Button(self.root, text="Predict Likes", command=self.predict_likes).grid(row=6, column=0, padx=10, pady=10)
        ttk.Button(self.root, text="Show Graph", command=show_graphical_presentation).grid(row=6, column=1, padx=10, pady=10)

    def predict_likes(self):
        try:
            hour_posted = self.hour_posted_var.get()
            post_length = self.post_length_var.get()
            hashtag_count = self.hashtag_count_var.get()
            followers = self.followers_var.get()
            num_comments = self.num_comments_var.get()
            video_play_count = self.video_play_count_var.get()

            likes_prediction = predict_likes_and_followers(hour_posted, post_length, hashtag_count, followers, num_comments, video_play_count)
            messagebox.showinfo("Prediction Result", f"Predicted Likes: {likes_prediction:.2f}")
        except Exception as e:
            messagebox.showerror("Error", str(e))

# Create the application window
root = tk.Tk()
app = PredictionApp(root)
root.mainloop()
'''